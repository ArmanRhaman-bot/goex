# Goex AI — Telegram Mini App

A mobile-first Telegram Mini App inspired by the supplied Goex AI screenshots. It includes:

- Telegram Mini App authentication with server-side `initData` validation.
- Mandatory Telegram channel membership gate.
- Home / Friends / Gifts / Account navigation.
- Referral system with coins + deposit percentage.
- Gift boxes and daily check-in.
- Configurable tasks.
- USDT deposits through OxaPay Merchant Invoice API.
- USDT/TRX/GRAM withdrawal flow through OxaPay Payout API.
- OxaPay webhook verification with HMAC-SHA512.
- Account history and withdrawal history.
- BTC/USDT market screen using Binance public market data.
- Light/dark theme.
- Admin panel with user search, balances, channel settings, reward settings, task management, gift settings, and admin-entry-user setting.
- Admin panel is only exposed in the Mini App to the configured Telegram user ID.

## 1. Important security step

The Telegram bot token pasted in the chat should be considered exposed. **Revoke it with @BotFather and create a new token before deployment.** Put the new token only in Render environment variables.

Never commit `.env` to GitHub.

## 2. MongoDB

Create a MongoDB Atlas database and copy its connection string into `MONGODB_URI`.

The app creates these collections automatically:
`users`, `transactions`, `withdrawals`, `deposits`, `tasks`, `settings`, `admins`.

## 3. OxaPay

Create a Merchant API key and a Payout API key in OxaPay. The current OxaPay API used here is:

- Invoice: `POST https://api.oxapay.com/v1/payment/invoice`
- Payment information: `GET https://api.oxapay.com/v1/payment/{track_id}`
- Payout: `POST https://api.oxapay.com/v1/payout`

Set the two keys in Render. The payout API may require 2FA, transfer limits and allowed-IP configuration in OxaPay.

Set your OxaPay callback URLs to:

`https://YOUR-RENDER-SERVICE.onrender.com/api/webhooks/oxapay`

The same endpoint handles invoice and payout callbacks and verifies the HMAC header.

## 4. Telegram

1. Add the bot as an administrator of the required channel. Telegram's `getChatMember` is used to enforce membership.
2. Set `CHANNEL_USERNAME` to the channel username, e.g. `@mychannel`.
3. Set `CHANNEL_JOIN_URL` to the public channel link.
4. Configure the Mini App URL with @BotFather.
5. Open the Mini App from the bot.

For a production Mini App, Telegram requires HTTPS.

## 5. Render

Create a Web Service from this repository.

Build command:
`npm install`

Start command:
`npm start`

Environment variables:
copy `.env.example` into Render and fill every value.

## 6. Admin

The first admin-entry user is `ADMIN_ENTRY_USER_ID`.

That user sees the Admin button in Account. The admin login page is `/admin`.

The first password comes from `ADMIN_PASSWORD`. After deployment, use the panel to change the configured admin-entry Telegram ID. The actual admin password is stored as a bcrypt hash.

## 7. Notes about balances

Deposits are credited only after an OxaPay `Paid` callback (and duplicate callbacks are protected by a unique track ID).

Withdrawals are reserved from the user's balance before the OxaPay payout request. A failed/rejected payout restores the reserved amount.

For production money handling, test with small amounts first and keep OxaPay limits/2FA enabled.

## 8. Frontend customization

The main visual theme is controlled in `public/styles.css`. The green palette, rounded cards, floating home button, bottom navigation and light/dark screens are intentionally close to the supplied references without copying any third-party branding assets.

